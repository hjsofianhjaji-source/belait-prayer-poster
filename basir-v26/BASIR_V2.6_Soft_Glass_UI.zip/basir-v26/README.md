# BASIR V2.6

Soft-glass UI refinement with lighter borders and better photo visibility.
